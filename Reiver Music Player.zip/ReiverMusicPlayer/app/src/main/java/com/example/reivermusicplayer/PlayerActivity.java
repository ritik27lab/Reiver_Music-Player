package com.example.reivermusicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.gauravk.audiovisualizer.visualizer.BarVisualizer;

import java.io.File;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {

    Button btnplay, btnnext , btnpause;
    TextView txtname , txtstart , txtstop;
    SeekBar seekMusic;
    BarVisualizer visualizer;

    String sname;
    public static final String EXTRA_NAME = "song_name";
    static MediaPlayer mediaPlayer;
    int position;
    ArrayList <File> mySongs;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);


        btnnext = findViewById(R.id.nextbtn);
        btnplay = findViewById(R.id.playbtn);
        btnpause = findViewById(R.id.previousbtn);
        txtname = findViewById(R.id.txtsn);
        txtstart = findViewById(R.id.txtsstart);
        txtstop = findViewById(R.id.txtsstop);
        seekMusic = findViewById(R.id.seekbar);
        visualizer = findViewById(R.id.blast);

        if (mediaPlayer != null ){
            mediaPlayer.stop();
            mediaPlayer.release();
        }

        Intent i = getIntent();
        Bundle bundle = i.getExtras();

        mySongs = (ArrayList) bundle.getParcelableArrayList("songs");
        String songName = i.getStringExtra("songname");
        position = bundle.getInt("pos" ,0);
        txtname.setSelected(true);
        Uri uri = Uri.parse(mySongs.get(position).toString());
        sname = mySongs.get(position).getName();
        txtname.setText(sname);

        mediaPlayer = MediaPlayer.create(getApplicationContext() , uri);
        mediaPlayer.start();

        btnplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()){
                    btnplay.setBackgroundResource(R.drawable.play);
                    mediaPlayer.pause();

                }
                else{
                    btnplay.setBackgroundResource(R.drawable.pause);
                    mediaPlayer.start();
                }

            }
        });


    }
}